<?php

namespace AutomateWoo\Exceptions;

/**
 * AutomateWoo Exception Interface.
 *
 * @since   4.9.0
 * @package AutomateWoo\Exceptions
 */
interface Exception {}
